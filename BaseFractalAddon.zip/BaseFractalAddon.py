bl_info = {
    "name": "3D Fractal Generator",
    "author": "Logmegiga",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "",
    "description": "A simple addon which allow you to spawn a fractal by specifying its length and the level of detail desired",
    "warning": "You must rename the generated object to generate another one or delete it to try again",
    "doc_url": "",
    "category": "Procedural 3D Geometry",
}

import bpy
from math import *

from bpy.types import(
    Panel,
    Operator,
    PropertyGroup,
    )
    
from bpy.props import(
    StringProperty,
    PointerProperty,
    FloatProperty,
    IntProperty
    )
    
class FractalPanel(Panel):
    bl_label = "Fractal Panel Setting"
    bl_idname = "OBJECT_PT_fractal"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fractal addon"

    def draw(self, context):
        layout = self.layout
        
        scene = context.scene.fractal_properties
        col = layout.column()
        col.prop(scene,"length")
        col.prop(scene,"maxIteration")
        col = layout.column()
        col.operator("coupole.generator")
        col = layout.column()
        col.operator("coupole.cleansing")
        col = layout.column()
        col.prop(scene,"fractalName")
        col.operator("coupole.name")


class FractalOperator(Operator):
    bl_idname = "coupole.generator"
    bl_label = "GENERATE"
    bl_description = "spawn a base 3D fractal"

    def execute(self, context):
        #main(context)
        scene = context.scene.fractal_properties
        length = scene.length
        n_max = scene.maxIteration
        spawnFractal(length,n_max)
        return {'FINISHED'}
    
class cleansingOperator(Operator):
    bl_idname = "coupole.cleansing"
    bl_label = "CLEAN"
    bl_description = "delete previous iteration objects from the viewport"

    def execute(self, context):
        #main(context)
        scene = context.scene.fractal_properties
        n_max = scene.maxIteration
        cleanFractal(n_max)
        return {'FINISHED'}
    
class renameOperator(Operator):
    bl_idname = "coupole.name"
    bl_label = "RENAME"
    bl_description = "change the name of the generated object after cleansing"

    def execute(self, context):
        #main(context)
        scene = context.scene.fractal_properties
        customName = scene.fractalName
        n_max = scene.maxIteration
        bpy.data.objects["BaseShape-"+str(n_max-1)].name = customName
        return {'FINISHED'}
    
class fractal_Properties(PropertyGroup):
    length : FloatProperty(
        name = "length",
        description = "the size of your fractal",
        default = 10
    )
    
    maxIteration : IntProperty(
        name = "Level Of Details",
        description = "the level of details entailed by the fractal process",
        default = 2
    )
    
    fractalName : StringProperty(
        name="Name",
        description="display name in the collection tab",
        default="BaseShape"
    )


classes = (
    FractalPanel,
    FractalOperator,
    cleansingOperator,
    renameOperator,
    fractal_Properties
    )

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fractal_properties = PointerProperty(type=fractal_Properties)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.fractal_properties

if __name__ == "__main__":
    register()
#####################################################################################################################################################################
##############################################################____FRACTAL CODE____###################################################################################
#####################################################################################################################################################################    
import math
from mathutils import Vector
 
def baseShape(name, length, origin=Vector((0,0,0))):
    #components
    coords = [
       origin + Vector((length/2,length/2,0)),
        origin + Vector((length/2,-length/2,0)),
        origin + Vector((-length/2,-length/2,0)),
        origin + Vector((-length/2,length/2,0)),

        ]
    edges=[]
    faces=[
        (0,1,2,3),
    ]
    
    #create new mesh and new object
    mesh = bpy.data.meshes.new(f'{name}-mesh')
    obj = bpy.data.objects.new(name,mesh)
    
    #make mesh from shape components
    mesh.from_pydata(coords,edges,faces)
    
    #show name and update the mesh
    mesh.update()
    
    #link object to active collection
    bpy.context.collection.objects.link(obj)
    
    return obj

#initialization
length = 100
angle = math.pi/4

primaryPivotPoints = [
    (length/2,0,0),
    (0,-length/2,0),
    (-length/2,0,0),
    (0,length/2,0),
]
    

##cursor3D setting
origin = (0,0,0)

def spawnShapeFractal(length, j):
    #Initialize the geometry shape
    baseShape('CenterMotion-'+str(j), length)
    centerMotion = bpy.context.scene.objects['CenterMotion-'+str(j)]

    baseShape('RightMotion-'+str(j), length)
    rightMotion = bpy.context.scene.objects['RightMotion-'+str(j)]
    rightMotion.rotation_euler.y = angle
    rightMotion.location.x = 0.5*length*(1+math.cos(angle))
    rightMotion.location.z = -0.5*length*math.sin(angle)


    baseShape('LeftMotion-'+str(j), length)
    leftMotion = bpy.context.scene.objects['LeftMotion-'+str(j)]
    leftMotion.rotation_euler.y = -angle
    leftMotion.location.x = -0.5*length*(1+math.cos(angle))
    leftMotion.location.z = -0.5*length*math.sin(angle)

    baseShape('FrontMotion-'+str(j), length)
    frontMotion = bpy.context.scene.objects['FrontMotion-'+str(j)]
    frontMotion.rotation_euler.x = -angle
    frontMotion.location.y = 0.5*length*(1+math.cos(angle))
    frontMotion.location.z = -0.5*length*math.sin(angle)

    baseShape('BackMotion-'+str(j), length)
    backMotion = bpy.context.scene.objects['BackMotion-'+str(j)]
    backMotion.rotation_euler.x = angle
    backMotion.location.y = -0.5*length*(1+math.cos(angle))
    backMotion.location.z = -0.5*length*math.sin(angle)

    # Deselect all objects
    bpy.ops.object.select_all(action='DESELECT')

    #Select and join selection
    for o in bpy.data.objects:
        # Check for given object names
        if o.name in ("CenterMotion-"+str(j),"RightMotion-"+str(j),"LeftMotion-"+str(j),"FrontMotion-"+str(j),"BackMotion-"+str(j)):
            o.select_set(True)
            
    centerMotion.select_set(state=True)
    bpy.context.view_layer.objects.active = centerMotion
    bpy.ops.object.join()
    bpy.data.objects["CenterMotion-"+str(j)].name = "BaseShape-"+str(j)
    
    return centerMotion

def spawnFractal(length,n_max):
    offset = 0
    offsetH = 0
    offsetV = 0
    for i in range(n_max):
        print('start loop fractal pool recursion at index: '+str(i))
        if(i==0):
            offsetH+= 0.5*(length / ((1+2*math.sin(angle))**i))*(1+math.sin(angle))
            spawnShapeFractal(length,0)
        if(i==1):
            baseShape = bpy.context.scene.objects['BaseShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angle))**i))*math.cos(angle)
 
            offsetH += 0.5* (length / ((1+2*math.sin(angle))**i))

            rightMotion.rotation_euler.y = angle
            rightMotion.location.x += offsetH
            rightMotion.location.z += -0.5*math.sin(angle) * (length / ((1+2*math.sin(angle))**i))

            leftMotion.rotation_euler.y = -angle
            leftMotion.location.x -= offsetH
            leftMotion.location.z += -0.5*math.sin(angle) * (length / ((1+2*math.sin(angle))**i))

            frontMotion.rotation_euler.x = -angle
            frontMotion.location.y += offsetH
            frontMotion.location.z += -0.5*math.sin(angle) * (length / ((1+2*math.sin(angle))**i))

            backMotion.rotation_euler.x = angle
            backMotion.location.y -= offsetH
            backMotion.location.z += -0.5*math.sin(angle) * (length / ((1+2*math.sin(angle))**i))

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseShape-"+str(i)+"_C",
                "BaseShape-"+str(i)+"_R",
                "BaseShape-"+str(i)+"_L",
                "BaseShape-"+str(i)+"_F",
                "BaseShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BaseShape-"+str(i)+"_C"].name = "BaseShape-"+str(i)
            
        if(i==2):
            baseShape = bpy.context.scene.objects['BaseShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angle))**i))*math.cos(angle)

            offsetH = 0
            for K in range(i+1):
                if K==0:
                    offsetH += 0.5*(length / ((1+2*math.sin(angle))**K))*(1+math.sin(angle))
                if K>0:
                    offsetH +=(length / ((1+2*math.sin(angle))**K))/2
                    
            offsetV = 0
            for V in range(i):
                if(i-V==2):
                    offsetV += 0.5*(length / ((1+2*math.sin(angle))**(i-V)))*math.sin(angle)
                else:
                    offsetV +=(length / ((1+2*math.sin(angle))**1))*math.sin(angle)
                    
            if(offsetV==(0.5*(length / ((1+2*math.sin(angle))**2))*math.sin(angle) + (length / ((1+2*math.sin(angle))**1))*math.sin(angle))):
                print('test ok')

                    
            rightMotion.rotation_euler.y = angle
            rightMotion.location.x += offsetH
            rightMotion.location.z -= offsetV

            leftMotion.rotation_euler.y = -angle
            leftMotion.location.x -= offsetH
            leftMotion.location.z -= offsetV

            frontMotion.rotation_euler.x = -angle
            frontMotion.location.y += offsetH
            frontMotion.location.z += -offsetV

            backMotion.rotation_euler.x = angle
            backMotion.location.y -= offsetH
            backMotion.location.z += -offsetV

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseShape-"+str(i)+"_C",
                "BaseShape-"+str(i)+"_R",
                "BaseShape-"+str(i)+"_L",
                "BaseShape-"+str(i)+"_F",
                "BaseShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BaseShape-"+str(i)+"_C"].name = "BaseShape-"+str(i)
            
        if(i>2):
            baseShape = bpy.context.scene.objects['BaseShape-'+str(i-1)]
            for cloneI in range(5):
                bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})
            for partI in range(5):
                if(partI==0):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_C"
                if(partI==1):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_R"
                if(partI==2):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_L"
                if(partI==3):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_F"
                if(partI==4):
                    bpy.data.objects["BaseShape-"+str(i-1)+".00"+str(partI+1)].name = "BaseShape-"+str(i)+"_B"
                    
            centerMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_C']
            rightMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_R']
            leftMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_L']
            frontMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_F']
            backMotion = bpy.context.scene.objects['BaseShape-'+str(i)+'_B']

            centerMotion.scale /= (1+math.sqrt(2))
            rightMotion.scale /= (1+math.sqrt(2))
            leftMotion.scale /= (1+math.sqrt(2))
            frontMotion.scale /= (1+math.sqrt(2))
            backMotion.scale /= (1+math.sqrt(2))

            centerMotion.location.z += (length / ((1+2*math.sin(angle))**i))*math.cos(angle)

            offsetH = 0
            for K in range(i+1):
                if K==0:
                    offsetH += 0.5*(length / ((1+2*math.sin(angle))**K))*(1+math.sin(angle))
                if K>0:
                    offsetH +=  (length / ((1+2*math.sin(angle))**K))/2
   
            offsetV = 0
            for V in range(i):
                if(V>0):
                    offsetV += (length / ((1+2*math.sin(angle))**V))*math.cos(angle)
                    
            if(offsetH== (0.5*(length / ((1+2*math.sin(angle))**0))*(1+math.sin(angle))+(length / ((1+2*math.sin(angle))**1))/2+(length / ((1+2*math.sin(angle))**2))/2+(length / ((1+2*math.sin(angle))**3))/2)):
                print('test ok')

            rightMotion.location.z -= offsetV
            leftMotion.location.z -= offsetV
            frontMotion.location.z -= offsetV
            backMotion.location.z -= offsetV

            rightMotion.rotation_euler.y = angle
            rightMotion.location.x += offsetH
            rightMotion.location.z += -0.5*(length / ((1+2*math.sin(angle))**i))*math.sin(angle)

            leftMotion.rotation_euler.y = -angle
            leftMotion.location.x -= offsetH
            leftMotion.location.z += -0.5*(length / ((1+2*math.sin(angle))**i))*math.sin(angle)

            frontMotion.rotation_euler.x = -angle
            frontMotion.location.y += offsetH
            frontMotion.location.z += -0.5*(length / ((1+2*math.sin(angle))**i))*math.sin(angle)

            backMotion.rotation_euler.x = angle
            backMotion.location.y -= offsetH
            backMotion.location.z += -0.5*(length / ((1+2*math.sin(angle))**i))*math.sin(angle)

            bpy.ops.object.select_all(action='DESELECT')

            nameList = [
                "BaseShape-"+str(i)+"_C",
                "BaseShape-"+str(i)+"_R",
                "BaseShape-"+str(i)+"_L",
                "BaseShape-"+str(i)+"_F",
                "BaseShape-"+str(i)+"_B"
            ]
                
            #Select and join selection
            for o in bpy.data.objects:
                # Check for given object names
                if o.name in (nameList[0],nameList[1],nameList[2],nameList[3],nameList[4]):
                    o.select_set(True)
                    
            centerMotion.select_set(state=True)
            bpy.context.view_layer.objects.active = centerMotion
            bpy.ops.object.join()
            
            bpy.data.objects["BaseShape-"+str(i)+"_C"].name = "BaseShape-"+str(i)
            
            
def cleanFractal(n):
    bpy.context.active_object.select_set(False)
    collection = bpy.data.collections['Collection']
    for h in range(n-1):
        collection.objects['BaseShape-'+str(h)].select_set(True)
        bpy.ops.object.delete(use_global=False)
